<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__currentLoopData = $crops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Modal -->
    <div class="modal fade" id="detailsModal<?php echo e($crop->id); ?>" tabindex="-1" aria-labelledby="detailsModalLabel<?php echo e($crop->id); ?>" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="detailsModalLabel<?php echo e($crop->id); ?>"><?php echo e($crop->crop_name); ?> - Full Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><?php echo e($crop->crop_details); ?></p>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow-sm border-0 rounded-3">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">Crops</h5>
                            </div>
                            <div class="card-body">
                                <?php if(session()->has('success')): ?>
                                <div class="alert alert-success">
                                    <strong>Success!</strong> <?php echo e(session('success')); ?>.
                                </div>
                                <?php endif; ?>
                                <table id="userTable" class="table">
                                    <thead class="table-success">
                                        <tr>
                                            <th>#</th>
                                            <th>Category</th>
                                            <th>Crop Name</th>
                                            <th>Image</th>
                                            <th>Details</th>
                                            <th>Type Info</th>
                                            <th>Action</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $crops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><?php echo e($crop->category->name ?? 'N/A'); ?></td>
                                            <td><?php echo e($crop->crop_name); ?></td>
                                            <td>
                                                <img src="<?php echo e(env('APP_URL') . 'public/crops/' . $crop->crop_image); ?>" alt="Crop Image" width="80">
                                            </td>
                                            <td>
                                                <?php echo e(Str::limit($crop->crop_details, 60)); ?>

                                                <?php if(Str::length($crop->crop_details) > 60): ?>
                                                <a href="#" data-bs-toggle="modal" data-bs-target="#detailsModal<?php echo e($crop->id); ?>">Read more</a>
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <?php
                                                $typeInfo = json_decode($crop->details_type_json, true);
                                                ?>
                                                <ul class="list-unstyled mb-0">
                                                    <?php $__currentLoopData = $typeInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><strong><?php echo e($item['type']); ?>:</strong> <?php echo e($item['name']); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('Crops.edit', $crop->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                                            </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" class="text-center text-muted">No crops found.</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script><?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/Crops/uploads_crops.blade.php ENDPATH**/ ?>