<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow-sm border-0 rounded-3">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">Edit Category</h5>
                            </div>
                            <div class="card-body">
                                <?php if(session()->has('success')): ?>
                                <div class="alert alert-success">
                                    <strong>Success!</strong> <?php echo e(session('success')); ?>.
                                </div>
                                <?php endif; ?>

                                <form action="<?php echo e(route('Crops.update', $crop->id)); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="mb-3">
                                        <label class="form-label">Crop Category</label>
                                        <select class="form-control" name="category_id" required>
                                            <option value="">Select Crop Category</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>" <?php echo e($crop->category_id == $cat->id ? 'selected' : ''); ?>>
                                                <?php echo e($cat->name); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Crop Name</label>
                                        <input type="text" class="form-control" name="crop_name" value="<?php echo e($crop->crop_name); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Crop Image</label><br>
                                        <img src="<?php echo e(env('APP_URL') . 'public/crops/' . $crop->crop_image); ?>" width="100" class="mb-2"><br>
                                        <input type="file" class="form-control" name="crop_image" accept="image/*">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Crop Details</label>
                                        <textarea class="form-control" name="crop_details" rows="4" required><?php echo e($crop->crop_details); ?></textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Details Type</label>
                                        <table class="table table-bordered" id="detailsTypeTable">
                                            <thead>
                                                <tr>
                                                    <th>Type</th>
                                                    <th>Name</th>
                                                    <th style="width: 50px;">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><input type="text" name="types[]" class="form-control" value="<?php echo e($detail['type']); ?>" required></td>
                                                    <td><input type="text" name="names[]" class="form-control" value="<?php echo e($detail['name']); ?>" required></td>
                                                    <td class="text-center">
                                                        <button type="button" class="btn btn-sm btn-danger remove-row">&times;</button>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <button type="button" id="addMore" class="btn btn-sm btn-primary">Add More</button>
                                    </div>

                                    <div class="text-end">
                                        <button type="submit" class="btn btn-success">Update Crop</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    document.getElementById('addMore').addEventListener('click', function() {
        const table = document.querySelector('#detailsTypeTable tbody');
        const newRow = `
            <tr>
                <td><input type="text" name="types[]" class="form-control" required></td>
                <td><input type="text" name="names[]" class="form-control" required></td>
                <td class="text-center">
                    <button type="button" class="btn btn-sm btn-danger remove-row">&times;</button>
                </td>
            </tr>
        `;
        table.insertAdjacentHTML('beforeend', newRow);
    });

    document.addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('remove-row')) {
            e.target.closest('tr').remove();
        }
    });
</script><?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/Crops/crop_edit.blade.php ENDPATH**/ ?>