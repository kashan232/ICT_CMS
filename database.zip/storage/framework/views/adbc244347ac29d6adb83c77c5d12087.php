<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow-sm border-0 rounded-3">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">Add New Uploads</h5>
                            </div>
                            <div class="card-body">
                                <?php if(session()->has('success')): ?>
                                <div class="alert alert-success">
                                    <strong>Success!</strong> <?php echo e(session('success')); ?>.
                                </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('pdf.upload')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="mb-3">
                                        <label for="pdf_type" class="form-label">PDF Type</label>
                                        <select name="pdf_type" id="pdf_type" class="form-select" required>
                                            <option value="">Select Type</option>
                                            <option value="Booklets">Booklets</option>
                                            <option value="Magazines">Magazines</option>
                                            <option value="Field Guide">Field Guide</option>
                                            <option value="Publication">Publication</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="title" class="form-label">Title</label>
                                        <input type="text" name="title" id="title" class="form-control" placeholder="Enter title" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="date" class="form-label">Date</label>
                                        <input type="date" name="date" id="date" class="form-control" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" required>
                                    </div>


                                    <div class="mb-3">
                                        <label for="cover_photo" class="form-label">Cover Photo</label>
                                        <input type="file" name="cover_photo" id="cover_photo" class="form-control" accept="image/*" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="pdf_file" class="form-label">PDF File</label>
                                        <input type="file" name="pdf_file" id="pdf_file" class="form-control" accept="application/pdf" required>
                                    </div>

                                    <div class="text-end">
                                        <button type="submit" class="btn btn-success">Upload</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/Upload_PDFs/New_Uploads.blade.php ENDPATH**/ ?>