<script src="assets/js/vendor.min.js"></script>
<script src="assets/vendor/daterangepicker/moment.min.js"></script>
<script src="assets/vendor/daterangepicker/daterangepicker.js"></script>
<script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
<script src="assets/vendor/jsvectormap/jsvectormap.min.js"></script>
<script src="assets/vendor/jsvectormap/maps/world-merc.js"></script>
<script src="assets/vendor/jsvectormap/maps/world.js"></script>
<script src="assets/js/pages/demo.dashboard.js"></script>
<script src="assets/js/app.min.js"></script>



</body>

</html><?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/includes/footer_links.blade.php ENDPATH**/ ?>