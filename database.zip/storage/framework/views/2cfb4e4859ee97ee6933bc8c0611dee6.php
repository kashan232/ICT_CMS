<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <script>
                    document.write(new Date().getFullYear())
                </script> © Hyper - Coderthemes.com
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/includes/footer.blade.php ENDPATH**/ ?>