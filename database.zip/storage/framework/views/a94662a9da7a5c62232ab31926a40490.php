<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow-sm border-0 rounded-3">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">Edit Category</h5>
                            </div>
                            <div class="card-body">
                                <?php if(session()->has('success')): ?>
                                <div class="alert alert-success">
                                    <strong>Success!</strong> <?php echo e(session('success')); ?>.
                                </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('categories.update', $categories->id)); ?>" method="POST" enctype="multipart/form-data">
                                   <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="mb-3">
                                        <label for="name" class="form-label">Name</label>
                                        <input type="text" name="name" id="name" class="form-control" placeholder="Enter title" value="<?php echo e($categories->name); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Old Category Image</label><br>
                                        <img src="<?php echo e(env('APP_URL') . 'public/categories/' . $categories->category_image); ?>" width="100" alt="Old Cover">
                                        <input type="hidden" name="old_cover" value="<?php echo e($categories->category_image); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="category_image" class="form-label">New Category Image (Optional)</label>
                                        <input type="file" name="category_image" id="category_image" class="form-control" accept="image/*">
                                    </div>

                                    <div class="text-end">
                                        <button type="submit" class="btn btn-success">Upload</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/Category/edit_Category.blade.php ENDPATH**/ ?>