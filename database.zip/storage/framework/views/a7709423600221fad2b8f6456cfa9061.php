<div class="leftside-menu">
    <a href="#" class="logo logo-light">
        <span class="logo-lg">
            <img src="<?php echo e(env('APP_URL')); ?>public/assets/images/Ict_logo.png" alt="logo">
        </span>
        <span class="logo-sm">
            <img src="<?php echo e(env('APP_URL')); ?>public/assets/images/logo-sm.png" alt="small logo">
        </span>
    </a>
    <a href="#" class="logo logo-dark">
        <span class="logo-lg">
            <img src="<?php echo e(env('APP_URL')); ?>public/assets/images/Ict_logo.png" alt="dark logo">
        </span>
        <span class="logo-sm">
            <img src="<?php echo e(env('APP_URL')); ?>public/assets/images/logo-dark-sm.png" alt="small logo">
        </span>
    </a>
    <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
        <i class="ri-checkbox-blank-circle-line align-middle"></i>
    </div>
    <div class="button-close-fullsidebar">
        <i class="ri-close-fill align-middle"></i>
    </div>
    <div class="h-100" id="leftside-menu-container" data-simplebar>
        <ul class="side-nav">
            <li class="side-nav-item">
                <a href="<?php echo e(route('home')); ?>" class="side-nav-link">
                    <i class="uil-home-alt"></i>
                    <span> Dashboards </span>
                </a>
            </li>

            <!-- <li class="side-nav-item">
                <a href="#" class="side-nav-link">
                    <i class="uil-comments-alt"></i>
                    <span> Chat </span>
                </a>
            </li> -->
            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#pdfsidebar" aria-expanded="false" aria-controls="pdfsidebar" class="side-nav-link">
                    <i class="uil-store"></i>
                    <span> Upload PDFs </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="pdfsidebar">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('new.uploads')); ?>">New Uploads</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('uploads')); ?>">Uploads</a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#Cropsidebar" aria-expanded="false" aria-controls="Cropsidebar" class="side-nav-link">
                    <i class="uil-store"></i>
                    <span> Crops Category </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="Cropsidebar">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('new.category.uploads')); ?>">New Category</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('categories')); ?>">Categories</a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#Crops" aria-expanded="false" aria-controls="Crops" class="side-nav-link">
                    <i class="uil-store"></i>
                    <span> Crops </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="Crops">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('new.Crops.uploads')); ?>">New Crops</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('Crops')); ?>">Crops</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('crops-management')); ?>">Crops Managements</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('crops-Diseases')); ?>">Diseases Managements</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('crops-Diseases-subtypes')); ?>">Diseases Types</a>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/includes/sidebar.blade.php ENDPATH**/ ?>