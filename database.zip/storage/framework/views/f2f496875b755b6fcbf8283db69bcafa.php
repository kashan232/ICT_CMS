<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow-sm border-0 rounded-3">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">Crops</h5>
                                <a href="<?php echo e(route('Diseases-management')); ?>" class="btn btn-secondary"> Add Diseases Management</a>
                            </div>
                            <div class="card-body">
                                <?php if(count($managements) > 0): ?>
                                <div class="card mt-5">
                                    <div class="card-body table-responsive">
                                        <table id="userTable" class="table">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>#</th>
                                                    <th>Category</th>
                                                    <th>Crop</th>
                                                    <th>Disease Types</th>
                                                    <th>Image</th>
                                                    <th>Created At</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $managements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($index + 1); ?></td>
                                                    <td><?php echo e($item->category_name); ?></td>
                                                    <td><?php echo e($item->crop_name); ?></td>
                                                    <td><?php echo e(ucfirst($item->type_name)); ?></td>
                                                    <td> 
                                                        <img src="<?php echo e(env('APP_URL') . 'public/disease/' . $item->image); ?>" width="60" alt="Cover">
                                                    </td>
                                                    <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('Y-m-d')); ?></td>
                                                    <td><a href="#" class="btn btn-primary btn-sm"> Edit </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script><?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/Crops/crops_Diseases.blade.php ENDPATH**/ ?>