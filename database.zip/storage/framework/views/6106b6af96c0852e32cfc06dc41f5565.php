<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow-sm border-0 rounded-3">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">PDFs Uploads</h5>
                            </div>
                            <div class="card-body">
                                <?php if(session()->has('success')): ?>
                                <div class="alert alert-success">
                                    <strong>Success!</strong> <?php echo e(session('success')); ?>.
                                </div>
                                <?php endif; ?>
                                 <table id="userTable" class="table">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>PDF Type</th>
                                        <th>Title</th>
                                        <th>Date</th>
                                        <th>Cover</th>
                                        <th>PDF File</th>
                                        <th>Action</th> <!-- New column -->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pdfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pdf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($pdf->pdf_type); ?></td>
                                        <td><?php echo e($pdf->title); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($pdf->date)->format('d M Y')); ?></td>
                                        <td>
                                            <img src="<?php echo e(env('APP_URL') . 'public/covers/' . $pdf->cover_photo); ?>" width="60" alt="Cover">
                                        </td>
                                        <td>
                                            <a href="<?php echo e(env('APP_URL') . 'public/pdfs/' . $pdf->pdf_file); ?>" target="_blank" class="btn btn-sm btn-primary">
                                                View PDF
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('pdfs.edit', $pdf->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

                                            <form action="<?php echo e(route('pdfs.destroy', $pdf->id)); ?>" method="POST" class="d-inline delete-form">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="button" class="btn btn-sm btn-danger delete-btn">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $(document).on('click', '.delete-btn', function (e) {
        e.preventDefault();
        var form = $(this).closest('form');

        Swal.fire({
            title: 'Are you sure?',
            text: "This PDF will be permanently deleted.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });
</script><?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/Upload_PDFs/Uploads.blade.php ENDPATH**/ ?>