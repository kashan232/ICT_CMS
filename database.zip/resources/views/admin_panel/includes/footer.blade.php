<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <script>
                    document.write(new Date().getFullYear())
                </script> © XCL - xcltechnologies.com
            </div>
        </div>
    </div>
</footer>