<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 mt-4">
                        <div class="card shadow-sm border-0 rounded-3">
                            <div class="card-header text-white" style="background-color:green !important;">
                                <h5 class="mb-0">Edit Document</h5>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('documents.update', $document->id)); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <div class="mb-3">
                                        <label class="form-label">Document Title</label>
                                        <input type="text" name="document_title" class="form-control" value="<?php echo e($document->document_title); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Date</label>
                                        <input type="date" name="date" class="form-control" value="<?php echo e($document->date); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Report No.</label>
                                        <input type="text" name="report_no" class="form-control" value="<?php echo e($document->report_no); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Document Type</label>
                                        <input type="text" name="document_type" class="form-control" value="<?php echo e($document->document_type); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Old PDF</label><br>
                                        <?php if($document->pdf_file): ?>
                                            <a href="<?php echo e(asset('storage/' . $document->pdf_file)); ?>" target="_blank" class="btn btn-sm btn-primary">View PDF</a>
                                        <?php else: ?>
                                            <span class="text-muted">No PDF</span>
                                        <?php endif; ?>
                                        <input type="hidden" name="old_pdf" value="<?php echo e($document->pdf_file); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">New PDF (Optional)</label>
                                        <input type="file" name="pdf_file" class="form-control" accept="application/pdf">
                                    </div>

                                    <div class="text-end">
                                        <button type="submit" class="btn" style="background-color:green !important; color:white !important">Update</button>
                                        <a href="<?php echo e(route('documents.index')); ?>" class="btn btn-secondary">Cancel</a>
                                    </div>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/documents/edit.blade.php ENDPATH**/ ?>