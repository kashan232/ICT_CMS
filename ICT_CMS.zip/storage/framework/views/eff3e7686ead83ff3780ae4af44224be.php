<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content-page">
        <div class="content">
            <div class="container-fluid">

                <div class="card shadow-sm mt-4">
                    <div class="card-header text-white" style="background-color:green;">
                        <h5>Add director general</h5>
                    </div>
                    <div class="card-body">

                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
<form method="POST" action="<?php echo e(url('/director-general/store')); ?>" enctype="multipart/multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="mb-3">
        <label>DG Name</label>
        <input type="text" name="Name" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>DG extension</label>
        <textarea name="dg-extension" class="form-control" rows="4" required></textarea>
    </div>

    <div class="mb-3">
        <label>Get to know us</label>
        <textarea name="know-us" class="form-control" rows="4" required></textarea>
    </div>

    <div id="heading-description-group">
        <div class="mb-3 border p-3 rounded heading-description-item">
            <h5>Heading & Description Type 1</h5>
            <div class="mb-3">
                <label>Heading</label>
                <textarea name="types[0][heading]" class="form-control" rows="2" required></textarea>
            </div>
            <div class="mb-3">
                <label>Description</label>
                <textarea name="types[0][description]" class="form-control" rows="4" required></textarea>
            </div>
        </div>

        <div class="mb-3 border p-3 rounded heading-description-item">
            <h5>Heading & Description Type 2</h5>
            <div class="mb-3">
                <label>Heading</label>
                <textarea name="types[1][heading]" class="form-control" rows="2" required></textarea>
            </div>
            <div class="mb-3">
                <label>Description</label>
                <textarea name="types[1][description]" class="form-control" rows="4" required></textarea>
            </div>
        </div>

        <div class="mb-3 border p-3 rounded heading-description-item">
            <h5>Heading & Description Type 3</h5>
            <div class="mb-3">
                <label>Heading</label>
                <textarea name="types[2][heading]" class="form-control" rows="2" required></textarea>
            </div>
            <div class="mb-3">
                <label>Description</label>
                <textarea name="types[2][description]" class="form-control" rows="4" required></textarea>
            </div>
        </div>
    </div>
    <div class="mb-3">
        <label>Main Image (Round)</label>
        <input type="file" name="main_image" class="form-control" accept="image/*">
    </div>

    <div class="text-end">
        <button type="submit" class="btn" style="background-color:green;color:white;">Add Extension</button>
        <a href="<?php echo e(url('/director-general')); ?>" class="btn btn-secondary">Cancel</a>
    </div>
</form>
                </div>

            </div>
        </div>
    </div>

    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/director/create.blade.php ENDPATH**/ ?>