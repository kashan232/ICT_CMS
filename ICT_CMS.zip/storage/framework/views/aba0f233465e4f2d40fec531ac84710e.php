<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content-page">
        <div class="content">
            <div class="container-fluid">

                <div class="card shadow-sm mt-4">
                    <div class="card-header text-white" style="background-color:green;">
                        <h5>Edit Director General</h5>
                    </div>
                    <div class="card-body">

                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>

<form method="POST" action="<?php echo e(route('director-general.update')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="edit_id" value="<?php echo e($director->id); ?>">
    <div class="mb-3">
        <label>DG Name</label>
        <input type="text" name="Name" class="form-control" value="<?php echo e($director->name); ?>" required>
    </div>

    <div class="mb-3">
        <label>DG Extension</label>
        <textarea name="dg-extension" class="form-control" rows="4" required><?php echo e($director->dg_extension); ?></textarea>
    </div>

    <div class="mb-3">
        <label>Get to know us</label>
        <textarea name="know-us" class="form-control" rows="4" required><?php echo e($director->know_us); ?></textarea>
    </div>

    <?php
        $types = json_decode($director->types, true);
    ?>

    <div id="heading-description-group">
        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-3 border p-3 rounded heading-description-item">
            <h5>Heading & Description Type <?php echo e($index + 1); ?></h5>
            <div class="mb-3">
                <label>Heading</label>
                <textarea name="types[<?php echo e($index); ?>][heading]" class="form-control" rows="2" required><?php echo e($type['heading'] ?? ''); ?></textarea>
            </div>
            <div class="mb-3">
                <label>Description</label>
                <textarea name="types[<?php echo e($index); ?>][description]" class="form-control" rows="4" required><?php echo e($type['description'] ?? ''); ?></textarea>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mb-3">
        <label>Main Image (Round)</label><br>
        <?php if($director->main_image): ?>
            <img src="<?php echo e(env('APP_URL') . 'storage/'.$director->main_image); ?>" width="100" class="mb-2">
        <?php endif; ?>
        <input type="file" name="main_image" class="form-control" accept="image/*">
    </div>

    <div class="text-end">
        <button type="submit" class="btn" style="background-color:green;color:white;">Update</button>
        <a href="<?php echo e(url('/director-general')); ?>" class="btn btn-secondary">Cancel</a>
    </div>
</form>

                </div>

            </div>
        </div>
    </div>

    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/director/edit.blade.php ENDPATH**/ ?>