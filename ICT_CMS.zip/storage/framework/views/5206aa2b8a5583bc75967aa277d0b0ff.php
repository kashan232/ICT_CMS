<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content-page">
        <div class="content">
            <div class="container-fluid">

                <div class="card shadow-sm mt-4">
                    <div class="card-header text-white" style="background-color:green;">
                        <h5>Add Document</h5>
                    </div>
                    <div class="card-body">

                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('documents.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label>Document Title</label>
                                <input type="text" name="document_title" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label>Date</label>
                                <input type="date" name="date" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label>Report No.</label>
                                <input type="text" name="report_no" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label>Document Type</label>
                                <input type="text" name="document_type" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label>PDF File</label>
                                <input type="file" name="pdf_file" class="form-control" accept="application/pdf" required>
                            </div>

                            <div class="text-end">
                                <button type="submit" class="btn" style="background-color:green;color:white;">Add Document</button>
                                <a href="<?php echo e(route('documents.index')); ?>" class="btn btn-secondary">Cancel</a>
                            </div>

                        </form>

                </div>

            </div>
        </div>
    </div>

    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/documents/create.blade.php ENDPATH**/ ?>