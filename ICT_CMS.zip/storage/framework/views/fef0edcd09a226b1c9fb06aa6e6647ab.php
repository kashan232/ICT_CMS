<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
<?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-page">
    <div class="content">
        <div class="container-fluid">
            <div class="card-body mt-5">
                <div class="row mb-3">
                    <div class="col-lg-6"><h5 class="mb-0">Upcoming Tenders</h5></div>
                    <div class="col-lg-6 d-flex justify-content-end">
                        <a href="<?php echo e(route('upcomingtenders.create')); ?>" class="btn" style="background-color:green; color:white;">Add Tender</a>
                    </div>
                </div>

                <div class="card shadow-sm border-0 rounded-3">
                    <div class="card-body">
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table text-center" id="userTable">
                                <thead style="background-color:green; color:white;">
                                    <tr>
                                        <th class="text-white">#</th>
                                        <th class="text-white">Title</th>
                                        <th class="text-white">Description</th>
                                        <th class="text-white">Date</th>
                                        <th class="text-white">PDF</th>
                                        <th class="text-white">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $tenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($item->title); ?></td>
                                        <td><?php echo e(Str::limit($item->description, 50)); ?></td>
                                        <td><?php echo e($item->date); ?></td>
                                        <td>
                                            <?php if($item->pdf_file): ?>
                                                <a href="<?php echo e(asset('storage/' . $item->pdf_file)); ?>" target="_blank" class="btn btn-sm btn-primary">View PDF</a>
                                            <?php else: ?>
                                                <span class="text-muted">No PDF</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('upcomingtenders.edit', $item->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                            <form action="<?php echo e(route('upcomingtenders.destroy', $item->id)); ?>" method="POST" style="display:inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/upcomingtenders/index.blade.php ENDPATH**/ ?>