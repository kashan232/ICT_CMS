<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
       <div class="row">
                
                    <div class="col-md-12 mt-5">
                         
                            
                            <div class="card-body">
  
                            <div class="row ">
     <div class="col-lg-6       ">
 <h5 class="mb-0">News Uplaod</h5>
                                    </div>
                                    <div class="col-lg-6       ">
    <div class="card-header text-white d-flex justify-content-end">
    <a href="<?php echo e(route('news.create')); ?>" class="btn " style="background-color:green !important;color:white   !important">
        Add News
    </a>
</div>
                                    </div>
                            </div>  
                        <div class="card shadow-sm border-0 rounded-3 mt-2  ">
                          
                            <div class="card-body">
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <strong>Success!</strong> <?php echo e(session('success')); ?>.
    </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table id="userTable" class="table ">
            <thead style="background-color:green !important; color:white !important">
                <tr>
                    <th class="text-white">#</th>
                    <th class="text-white">Title</th>
                    <th class="text-white">Date</th>
                    <th class="text-white">Details</th>
                    <th class="text-white">Image</th>
                    <th class="text-white">PDF</th>
                    <th class="text-white">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($item->title); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($item->date)->format('d M Y')); ?></td>
                    <td style="max-width: 200px; overflow: auto; white-space: nowrap;">
    <?php echo e($item->details); ?>

</td>
<td>
    <?php if($item->image): ?>
        <a href="<?php echo e(env('APP_URL') . 'storage/' . $item->image); ?>" target="_blank">
            <img src="<?php echo e(env('APP_URL') . 'storage/' . $item->image); ?>" width="50" height="50" alt="Cover">
        </a>
    <?php endif; ?>
</td>

                    <td>
                        <?php if($item->pdf): ?>
                        <a href="<?php echo e(route('news.download', $item->id)); ?>" class="btn btn-sm btn-primary" target="_blank">Download PDF</a>
                        <?php else: ?>
                        <span class="badge bg-secondary">No PDF</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('news.edit', $item->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="<?php echo e(route('news.destroy', $item->id)); ?>" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $(document).on('click', '.delete-btn', function (e) {
        e.preventDefault();
        var form = $(this).closest('form');

        Swal.fire({
            title: 'Are you sure?',
            text: "This PDF will be permanently deleted.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });
</script><?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/news/index.blade.php ENDPATH**/ ?>