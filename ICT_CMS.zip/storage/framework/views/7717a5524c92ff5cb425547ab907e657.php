<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">

                <div class="card-body mt-5">
                    <div class="row mb-3">
                        <div class="col-lg-6"><h5 class="mb-0">Agriculture Extension Upload</h5></div>
                        
                    </div>

                    <div class="card shadow-sm border-0 rounded-3">
                        <div class="card-body">
                            <?php if(session()->has('success')): ?>
                                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                            <?php endif; ?>

                            <div class="table-responsive">
      <table class="table text-center" id="userTable">
    <thead style="background-color:green; color:white;">
        <tr class="text-white">
            <th class="text-white text-center">#</th>
            <th class="text-white text-center"> Name</th>
            <th class="text-white text-center"> Extension</th>
            <th class="text-white text-center">Know Us</th>
            <th class="text-white text-center">Headings & Descriptions</th>
            <th class="text-white text-center">Main Image</th>
            <th class="text-white text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e(Str::limit($item->dg_extension, 50)); ?></td>
                <td><?php echo e(Str::limit($item->know_us, 50)); ?></td>

                <td>
                    <?php
                        $types = json_decode($item->types, true);
                    ?>
                    <?php if($types): ?>
                        <ul class="text-start">
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <strong>Heading:</strong> <?php echo e($type['heading'] ?? ''); ?> <br>
                                    <strong>Description:</strong> <?php echo e($type['description'] ?? ''); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <span class="text-muted">No Data</span>
                    <?php endif; ?>
                </td>

                <td>
                    <?php if($item->main_image): ?>
                        <img src="<?php echo e(env('APP_URL') . 'storage/'.$item->main_image); ?>" width="100" height="70">
                    <?php else: ?>
                        <span class="text-muted">No Image</span>
                    <?php endif; ?>
                </td>

                <td>
                   <a href="<?php echo e(route('director-general.edit', $item->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>



                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/director/index.blade.php ENDPATH**/ ?>