<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
<?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-page">
    <div class="content">
        <div class="container-fluid">
            <div class="card shadow-sm mt-4">
                <div class="card-header text-white" style="background-color:green;">
                    <h5>Edit Tender</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('upcomingtenders.update', $tender->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label>Title</label>
                            <input type="text" name="title" value="<?php echo e($tender->title); ?>" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Description</label>
                            <textarea name="description" class="form-control" rows="4" required><?php echo e($tender->description); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label>Old PDF File</label><br>
                            <?php if($tender->pdf_file): ?>
                                <a href="<?php echo e(asset('storage/'.$tender->pdf_file)); ?>" target="_blank" class="btn btn-sm btn-primary">View PDF</a>
                            <?php else: ?>
                                <span class="text-muted">No PDF</span>
                            <?php endif; ?>
                            <input type="hidden" name="old_pdf" value="<?php echo e($tender->pdf_file); ?>">
                        </div>
                        <div class="mb-3">
                            <label>New PDF File (Optional)</label>
                            <input type="file" name="pdf_file" class="form-control" accept="application/pdf">
                        </div>
                        <div class="mb-3">
                            <label>Date</label>
                            <input type="date" name="date" value="<?php echo e($tender->date); ?>" class="form-control" required>
                        </div>
                        <div class="text-end">
                            <button class="btn" style="background-color:green;color:white;">Update Tender</button>
                            <a href="<?php echo e(route('upcomingtenders.index')); ?>" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/upcomingtenders/edit.blade.php ENDPATH**/ ?>