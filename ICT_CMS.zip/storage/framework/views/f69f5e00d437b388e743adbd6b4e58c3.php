 <?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 mt-5">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <h5 class="mb-0">Banner Upload</h5>
                                </div>
                                <div class="col-lg-6">
                                    <div class="card-header text-white d-flex justify-content-end">
                                        <a href="<?php echo e(route('banners.create')); ?>" class="btn" style="background-color:green !important;color:white !important">
                                            Add Banner
                                        </a>
                                    </div>
                                </div>
                            </div>  

                            <div class="card shadow-sm border-0 rounded-3 mt-2">
                                <div class="card-body">

                                    <?php if(session()->has('success')): ?>
                                    <div class="alert alert-success">
                                        <strong>Success!</strong> <?php echo e(session('success')); ?>

                                    </div>
                                    <?php endif; ?>

                                    <div class="table-responsive">
                                        <table id="userTable" class="table">
                                            <thead style="background-color:green !important; color:white !important">
                                                <tr>
                                                    <th class="text-white">#</th>
                                                    <th class="text-white">Title</th>
                                                    <th class="text-white">Description</th>
                                                    <th class="text-white">Image</th>
                                                    <th class="text-white">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($index + 1); ?></td>
                                                    <td><?php echo e($item->title); ?></td>
                                                    <td style="max-width: 200px; overflow: auto; white-space: nowrap;">
                                                        <?php echo e($item->description); ?>

                                                    </td>
                                                    <td>
                                                         <?php if($item->image): ?>
        <a href="<?php echo e(env('APP_URL') . 'storage/' . $item->image); ?>" target="_blank">
            <img src="<?php echo e(env('APP_URL') . 'storage/' . $item->image); ?>" width="50" height="50" alt="Cover">
        </a>
    <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('banners.edit',$item->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                                        <a href="<?php echo e(route('banners.delete',$item->id)); ?>" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">Delete</a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/banners/index.blade.php ENDPATH**/ ?>