<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 mt-4">
                        <div class="card shadow-sm border-0 rounded-3">
                            <div class="card-header text-white" style="background-color:green !important;">
                                <h5 class="mb-0">Edit District Office</h5>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('district.update')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                        <input type="text" name="edit_id" class="form-control" value="<?php echo e($data->id); ?>" required>
                                    
                                    <div class="mb-3">
                                        <label for="district_name" class="form-label">District Name</label>
                                        <input type="text" name="district_name" class="form-control" value="<?php echo e($data->district_name); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="headquarters" class="form-label">Headquarters</label>
                                        <input type="text" name="headquarters" class="form-control" value="<?php echo e($data->headquarters); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="area" class="form-label">Area</label>
                                        <input type="text" name="area" class="form-control" value="<?php echo e($data->area); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="population" class="form-label">Population</label>
                                        <input type="text" name="population" class="form-control" value="<?php echo e($data->population); ?>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="density" class="form-label">Density</label>
                                        <input type="text" name="density" class="form-control" value="<?php echo e($data->density); ?>" required>
                                    </div>

                                    <div class="text-end">
                                        <button type="submit" class="btn" style="background-color:green !important; color:white !important">Update</button>
                                        <a href="<?php echo e(url('/district')); ?>" class="btn btn-secondary">Cancel</a>
                                    </div>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/district/edit.blade.php ENDPATH**/ ?>