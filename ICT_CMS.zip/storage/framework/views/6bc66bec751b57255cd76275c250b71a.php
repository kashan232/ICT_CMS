<?php echo $__env->make('admin_panel.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
<?php echo $__env->make('admin_panel.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin_panel.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-page">
<div class="content">
<div class="container-fluid">
<div class="row">
<div class="col-md-12 mt-4">
<div class="card shadow-sm">
<div class="card-header" style="background-color:green;color:white;"><h5>Edit Department</h5></div>
<div class="card-body">
<form action="<?php echo e(route('departments.update', $department->id)); ?>" method="POST"><?php echo csrf_field(); ?>
<div class="mb-3"><label>Name</label><input type="text" name="department_name" class="form-control" value="<?php echo e($department->department_name); ?>" required></div>
<div class="mb-3"><label>email</label><input type="text" name="email" class="form-control" value="<?php echo e($department->email); ?>" required></div>
<div class="mb-3"><label>Location</label><input type="text" name="location" class="form-control" value="<?php echo e($department->location); ?>" required></div>
<div class="mb-3"><label>Timing</label><input type="text" name="timing" class="form-control" value="<?php echo e($department->timing); ?>" required></div>
<div class="mb-3"><label>Phone</label><input type="text" name="phone" class="form-control" value="<?php echo e($department->phone); ?>" required></div>
<button class="btn " style="background-color:green; color:white !important;">Update Department</button>
<a href="<?php echo e(route('departments.index')); ?>" class="btn btn-secondary">Cancel</a>
</form>
</div></div></div></div></div></div>
<?php echo $__env->make('admin_panel.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('admin_panel.includes.footer_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/departments/edit.blade.php ENDPATH**/ ?>