<style>
    /* styles.css */
.side-nav-link.active-link {
    background-color: green;
    color: white !important; /* To ensure text is visible on green background */
    border-radius: 5px; /* Optional: adds a slight curve to the corners */
}

/* For parent items with collapsable sub-menus */
.side-nav-item .side-nav-link.active-link {
    background-color: green;
    color: white !important;
    border-radius: 5px;
}

/* If you want the parent 'side-nav-item' to also have a background when a child is active */
.side-nav-item.active-parent > .side-nav-link {
    background-color: green;
    color: white !important;
    border-radius: 5px;
}   
.side-nav .menuitem-active .menuitem-active .active {
    color:green !important
}

</style>  
<style>
.leftside-menu {
    height: 100vh;
    overflow-y: auto;
}

/* Optional smooth scrollbar look */
.leftside-menu::-webkit-scrollbar {
    width: 6px;
}
.leftside-menu::-webkit-scrollbar-thumb {
    background-color: green;
    border-radius: 5px;
}
.logo {
    position: relative;
    z-index: 99;
}

.side-nav li, .side-nav {
    position: relative;
    z-index: 1;
}

</style>

<div class="leftside-menu bg-white text-dark">
    <a href="#" class="logo logo-light bg-white ">
        <span class="logo-lg mt-2 mb-4">
            <img src="<?php echo e(env('APP_URL')); ?>public/assets/images/Ict_logo.png" alt="logo" style="height:100px !important;width:100px">
        </span>
        <span class="logo-sm bg-white">
            <img src="<?php echo e(env('APP_URL')); ?>public/assets/images/Ict_logo.png" alt="small logo">
        </span>
    </a>
    <a href="#" class="logo logo-dark">
        <span class="logo-lg ">
            <img src="<?php echo e(env('APP_URL')); ?>public/assets/images/Ict_logo.png" alt="dark logo">
        </span>
        <span class="logo-sm bg-white">
            <img src="<?php echo e(env('APP_URL')); ?>public/assets/images/logo-dark-sm.png" alt="small logo">
        </span>
    </a>
    <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
        <i class="ri-checkbox-blank-circle-line align-middle"></i>
    </div>
    <div class="button-close-fullsidebar">
        <i class="ri-close-fill align-middle"></i>
    </div>
    <div class="h-100" id="leftside-menu-container" data-simplebar>
        <ul class="side-nav text-dark">
            <li class="side-nav-item">
                <a href="<?php echo e(route('home')); ?>" class="side-nav-link text-dark <?php echo e(Request::routeIs('home') ? 'active-link' : ''); ?>">
                    <i class="uil-home-alt"></i>
                    <span> Dashboards </span>
                </a>
            </li>

            <li class="side-nav-item <?php echo e(Request::routeIs('new.uploads', 'uploads') ? 'active-parent' : ''); ?>">
                <a data-bs-toggle="collapse" href="#pdfsidebar" aria-expanded="<?php echo e(Request::routeIs('new.uploads', 'uploads') ? 'true' : 'false'); ?>" aria-controls="pdfsidebar" class="side-nav-link text-dark   ">
                    <i class="uil-store"></i>
                    <span>PDFs Upload  </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse <?php echo e(Request::routeIs('new.uploads', 'uploads') ? 'show' : ''); ?>" id="pdfsidebar">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('new.uploads')); ?>" class="  <?php echo e(Request::routeIs('new.uploads') ? 'active-link' : ''); ?>  text-dark">New Uploads</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('uploads')); ?>" class="<?php echo e(Request::routeIs('uploads') ? 'active-link' : ''); ?> text-dark    ">Uploads</a>
                        </li>
                    </ul>
                </div>
            </li>
               <li class="side-nav-item <?php echo e(Request::routeIs('news.create', 'news.index') ? 'active-parent' : ''); ?>">
                <a data-bs-toggle="collapse" href="#newssidebar" aria-expanded="<?php echo e(Request::routeIs('news.create', 'news.index') ? 'true' : 'false'); ?>" aria-controls="pdfsidebar" class="side-nav-link text-dark   ">
                    <i class="uil-store"></i>
                    <span>News Upload </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse <?php echo e(Request::routeIs('news.create', 'news.index') ? 'show' : ''); ?>" id="newssidebar">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('news.create')); ?>" class="  <?php echo e(Request::routeIs('news.create') ? 'active-link' : ''); ?>  text-dark">News Uploads</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('news.index')); ?>" class="<?php echo e(Request::routeIs('news.index') ? 'active-link' : ''); ?> text-dark    ">Uploads</a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="side-nav-item <?php echo e(Request::routeIs('new.category.uploads', 'categories-list') ? 'active-parent' : ''); ?>">
                <a data-bs-toggle="collapse" href="#Cropsidebar" aria-expanded="<?php echo e(Request::routeIs('new.category.uploads', 'categories-list') ? 'true' : 'false'); ?>" aria-controls="Cropsidebar" class="side-nav-link text-dark">
                    <i class="uil-store"></i>
                    <span> Crops Category </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse <?php echo e(Request::routeIs('new.category.uploads', 'categories-list') ? 'show' : ''); ?>" id="Cropsidebar">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('new.category.uploads')); ?>" class="<?php echo e(Request::routeIs('new.category.uploads') ? 'active-link' : ''); ?> text-dark">New Category</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('categories-list')); ?>" class="<?php echo e(Request::routeIs('categories-list') ? 'active-link' : ''); ?> text-dark">Categories</a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="side-nav-item <?php echo e(Request::routeIs('new.Crops.uploads', 'Crops', 'crops-management', 'crops-Diseases', 'crops-Diseases-subtypes') ? 'active-parent' : ''); ?>">
                <a data-bs-toggle="collapse" href="#Crops" aria-expanded="<?php echo e(Request::routeIs('new.Crops.uploads', 'Crops', 'crops-management', 'crops-Diseases', 'crops-Diseases-subtypes') ? 'true' : 'false'); ?>" aria-controls="Crops" class="side-nav-link text-dark">
                    <i class="uil-store"></i>
                    <span> Crops </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse <?php echo e(Request::routeIs('new.Crops.uploads', 'Crops', 'crops-management', 'crops-Diseases', 'crops-Diseases-subtypes') ? 'show' : ''); ?>" id="Crops">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('new.Crops.uploads')); ?>" class="<?php echo e(Request::routeIs('new.Crops.uploads') ? 'active-link' : ''); ?> text-dark">New Crops</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('Crops')); ?>" class="<?php echo e(Request::routeIs('Crops') ? 'active-link' : ''); ?> text-dark">Crops</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('crops-management')); ?>" class="<?php echo e(Request::routeIs('crops-management') ? 'active-link' : ''); ?> text-dark">Crops Managements</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('crops-Diseases')); ?>" class="<?php echo e(Request::routeIs('crops-Diseases') ? 'active-link' : ''); ?> text-dark">Diseases Managements</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('crops-Diseases-subtypes')); ?>" class="<?php echo e(Request::routeIs('crops-Diseases-subtypes') ? 'active-link' : ''); ?> text-dark">Diseases Types</a>
                        </li>
                    </ul>
                </div>
            </li>
                 <li class="side-nav-item <?php echo e(Request::routeIs("departments.index",'allbanner.index','upcomingtenders.index','documents.index','director-general.index','district.index','headline.index','extension.index','banners.index','videos.index','subcenter.index') ? 'active-parent' : ''); ?>">
                <a data-bs-toggle="collapse" href="#dynamic" aria-expanded="<?php echo e(Request::routeIs('news.create','allbanner.index','upcomingtenders.index','documents.index','district.index','director-general.index','headline.index','extension.index','subcenter.index','videos.index', 'news.index') ? 'true' : 'false'); ?>" aria-controls="pdfsidebar" class="side-nav-link text-dark   ">
                    <i class="uil-store"></i>
                    <span>Web dynamic</span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse <?php echo e(Request::routeIs('departments.index','allbanner.index','documents.index','upcomingtenders.index','director-general.index','headline.index','district.index','extension.index','videos.index','banners.index','subcenter.index') ? 'show' : ''); ?>" id="dynamic">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('departments.index')); ?>" class="  <?php echo e(Request::routeIs('departments.index') ? 'active-link' : ''); ?>  text-dark">Header</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('banners.index')); ?>" class="<?php echo e(Request::routeIs('banners.index') ? 'active-link' : ''); ?> text-dark    ">home Banner</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('allbanner.index')); ?>" class="<?php echo e(Request::routeIs('allbanner.index') ? 'active-link' : ''); ?> text-dark    ">All Banners</a>
                        </li>
                           <li>
                            <a href="<?php echo e(route('videos.index')); ?>" class="<?php echo e(Request::routeIs('videos.index') ? 'active-link' : ''); ?> text-dark    ">Videos</a>
                        </li>
                         <li>
                            <a href="<?php echo e(route('subcenter.index')); ?>" class="<?php echo e(Request::routeIs('subcenter.index') ? 'active-link' : ''); ?> text-dark    ">Subcenter</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('headline.index')); ?>" class="<?php echo e(Request::routeIs('headline.index') ? 'active-link' : ''); ?> text-dark    ">Headlines</a>
                        </li>
                          <li>
                            <a href="<?php echo e(route('extension.index')); ?>" class="<?php echo e(Request::routeIs('extension.index') ? 'active-link' : ''); ?> text-dark    ">Extension About</a>
                        </li>
                          <li>
                            <a href="<?php echo e(route('director-general.index')); ?>" class="<?php echo e(Request::routeIs('director-general.index') ? 'active-link' : ''); ?> text-dark    ">Director about</a>
                        </li>
                           <li>
                            <a href="<?php echo e(route('district.index')); ?>" class="<?php echo e(Request::routeIs('district.index') ? 'active-link' : ''); ?> text-dark    ">District Offices</a>
                        </li>
                              <li>
                            <a href="<?php echo e(route('documents.index')); ?>" class="<?php echo e(Request::routeIs('documents.index') ? 'active-link' : ''); ?> text-dark    ">Projects</a>
                        </li>
                          <li>
                            <a href="<?php echo e(route('upcomingtenders.index')); ?>" class="<?php echo e(Request::routeIs('upcomingtenders.index') ? 'active-link' : ''); ?> text-dark    ">upcoming Tenders</a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="side-nav-item">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();" class="side-nav-link text-dark">
                      <i class="fa-solid fa-right-from-bracket"></i>
                        <span> Logout </span>
                    </a>
                </form>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\ICT_CMS\resources\views/admin_panel/includes/sidebar.blade.php ENDPATH**/ ?>